# My Gee MVP

This is a mobile-friendly Next.js + Supabase starter.

Included:
- email/password authentication
- companion selection
- Big Bro, Big Sis, Love and My Gee
- chat UI
- message persistence
- Supabase RLS
- API route ready for a real AI provider

Setup:
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase URL and anon key.
5. Run the SQL in `supabase/schema.sql` only if your existing database is missing anything.
6. Run `npm run dev`.

Never expose a Supabase service_role key in browser code.

The chat response is currently a placeholder. A real AI provider must be connected before public launch.
