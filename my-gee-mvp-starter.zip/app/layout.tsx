import "./globals.css";
export const metadata={title:"My Gee",description:"Your AI companion when you need one."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>;}
