"use client";
import{useEffect,useState}from"react";import{useRouter}from"next/navigation";import{createClient}from"../../lib/supabase-browser";
export default function CompanionsPage(){const s=createClient(),r=useRouter();const[c,setC]=useState<any[]>([]);const[e,setE]=useState("");
useEffect(()=>{(async()=>{const{data:{user}}=await s.auth.getUser();if(!user)return r.push("/auth");const{x,data}=await s.from("companions").select("id,name,type,description,active").eq("active",true).order("name");if(x)setE(x.message);else setC(data||[]);})()},[]);
const em:any={brother:"🧑🏾",sister:"👩🏾",love:"❤️",bestie:"🤝"};
return <main className="container" style={{paddingTop:45}}><h1>Choose your Gee</h1><p style={{color:"#b8bec7"}}>Pick the companion you want to talk to.</p>{e&&<p>{e}</p>}<div className="grid grid-4">{c.map(v=><button key={v.id} className="card" style={{textAlign:"left",cursor:"pointer",color:"#fff"}} onClick={()=>r.push("/chat/"+v.id)}><div style={{fontSize:45}}>{em[v.type]||"🤝"}</div><h2>{v.name}</h2><p style={{color:"#b8bec7"}}>{v.description}</p></button>)}</div></main>}
