# GEE MVP v10 — Beta-ready foundation

GEE combines an AI companion with human connection: **Talk. Connect. Belong.**

## v10 additions
- Stripe subscription persistence + signed webhook handling
- Supabase subscription status / `is_plus()` RPC
- Account deletion using Supabase Admin API
- Admin safety-report dashboard protected by `GEE_ADMIN_EMAILS`
- User privacy fields and server-side rate-limit RPC foundation
- Existing AI, realtime voice, matching, connections, messaging, notifications and reporting retained

## Setup
1. Copy `.env.example` to `.env.local` and fill in keys.
2. Run all SQL migrations in `supabase/migrations` in order.
3. Configure a Stripe webhook to `/api/stripe/webhook` and subscribe to checkout completion plus subscription created/updated/deleted events.
4. Set `SUPABASE_SERVICE_ROLE_KEY` only on the server; never expose it as a `NEXT_PUBLIC_*` variable.
5. Set `GEE_ADMIN_EMAILS` to the comma-separated emails allowed to access `/admin`.
6. Run `npm install && npm run dev`.

Before public launch, test RLS with multiple accounts, add production observability, verify rate-limit enforcement in every sensitive API route, and complete privacy/terms/legal review.
