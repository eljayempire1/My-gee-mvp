'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase/client';

type Match={id:string;display_name:string;city:string|null;bio:string|null;interests:string[];score:number};

export default function Matches(){
 const [matches,setMatches]=useState<Match[]>([]); const [loading,setLoading]=useState(true); const [error,setError]=useState('');
 useEffect(()=>{(async()=>{const {data,error}=await supabase.rpc('discover_people',{limit_count:20}); if(error)setError(error.message); else setMatches((data||[]) as Match[]); setLoading(false)})()},[]);
 return <main><nav className="nav"><div className="logo">GEE<span>.</span></div><div className="navlinks"><a href="/">Home</a><a href="/discover">Discover</a><a href="/messages">Messages</a><a href="/notifications">🔔</a></div></nav><section className="discover"><p className="eyebrow">SMART MATCHING</p><h1>Your people.</h1><p className="lead">GEE surfaces people with shared interests first. You decide who to connect with.</p>{loading&&<p>Finding your people…</p>}{error&&<p className="error">{error}</p>}<div className="people">{matches.map(m=><article className="person" key={m.id}><div className="avatar big">{(m.display_name||'?')[0]}</div><div className="person-main"><h3>{m.display_name}</h3><p className="muted">{m.city||'London'}</p><p>{m.bio||'Open to meeting new people.'}</p><div className="chips">{(m.interests||[]).map(i=><span key={i}>{i}</span>)}</div><p className="muted">{m.score} shared interest{m.score===1?'':'s'}</p></div></article>)}</div></section></main>
}
