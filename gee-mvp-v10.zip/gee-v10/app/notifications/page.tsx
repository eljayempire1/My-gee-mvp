'use client';
import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

type Note={id:string;title:string;body:string;read_at:string|null;created_at:string;type:string};
export default function Notifications(){
 const supabase=useMemo(()=>createClient(),[]); const [notes,setNotes]=useState<Note[]>([]); const [status,setStatus]=useState('Loading…');
 useEffect(()=>{let active=true;(async()=>{const {data:{user}}=await supabase.auth.getUser(); if(!user){setStatus('Please sign in.');return;} const {data,error}=await supabase.from('notifications').select('*').order('created_at',{ascending:false}).limit(50); if(error)setStatus(error.message); else if(active){setNotes((data||[]) as Note[]);setStatus('')}})(); return()=>{active=false}},[supabase]);
 async function markRead(id:string){await supabase.from('notifications').update({read_at:new Date().toISOString()}).eq('id',id);setNotes(ns=>ns.map(n=>n.id===id?{...n,read_at:new Date().toISOString()}:n));}
 return <main><nav className="nav"><div className="logo">GEE<span>.</span></div><div className="navlinks"><a href="/gee">My Gee</a><a href="/matches">People</a><a href="/messages">Messages</a><a href="/notifications">🔔</a><a className="btn ghost" href="/profile">Profile</a></div></nav><section className="chat-shell"><p className="eyebrow">GEE NOTIFICATIONS</p><h1>Stay connected.</h1><p className="lead">Connection requests, accepted connections and new activity in one place.</p>{status&&<p className="muted">{status}</p>}<div className="message-card">{notes.length===0&&!status?<p className="muted">You're all caught up. 🔥</p>:notes.map(n=><button key={n.id} onClick={()=>markRead(n.id)} style={{display:'block',width:'100%',textAlign:'left',padding:'16px',marginBottom:'10px',borderRadius:'16px',border:'1px solid var(--border)',background:n.read_at?'transparent':'var(--card)',cursor:'pointer'}}><strong>{n.title}</strong><p className="muted">{n.body}</p><small className="muted">{new Date(n.created_at).toLocaleString()}</small></button>)}</div></section></main>
}
