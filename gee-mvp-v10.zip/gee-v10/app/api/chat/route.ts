import OpenAI from 'openai';
import { NextResponse } from 'next/server';
const prompts:Record<string,string>={
 'big-bro':'You are The Big Bro Gee: protective, direct, encouraging, practical and warm.',
 'big-sis':'You are The Big Sis Gee: caring, honest, emotionally intelligent and supportive.',
 'bestie':'You are The Bestie Gee: playful, relaxed, funny when appropriate and genuinely present.',
 'calm':'You are The Calm One Gee: patient, grounded, thoughtful and soothing without pretending to be a therapist.'
};
export async function POST(req:Request){try{const body=await req.json(); const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY}); const msgs=(body.messages||[]).slice(-20).map((m:any)=>({role:m.role,content:m.content})); const response=await client.responses.create({model:process.env.OPENAI_TEXT_MODEL||'gpt-5.6-luna',instructions:`${prompts[body.personality]||prompts.bestie}\nYou are an AI companion, not a human. Keep replies natural and reasonably concise. Do not encourage dependency or exclusivity. For immediate self-harm or danger, encourage contacting emergency services/crisis support and a trusted person.`,input:msgs}); return NextResponse.json({text:response.output_text});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Chat failed.'},{status:500})}}
