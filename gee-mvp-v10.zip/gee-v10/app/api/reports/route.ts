import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });
  const body = await req.json();
  const { reportedUserId, reason, details } = body;
  const allowed = ['harassment','spam','scam','sexual_content','threats','other'];
  if (!reportedUserId || !allowed.includes(reason) || reportedUserId === user.id) {
    return NextResponse.json({ error: 'Invalid report.' }, { status: 400 });
  }
  const { error } = await supabase.from('reports').insert({ reporter_id: user.id, reported_user_id: reportedUserId, reason, details: details?.slice(0, 2000) ?? null });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
