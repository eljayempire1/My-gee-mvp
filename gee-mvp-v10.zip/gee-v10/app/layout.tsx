import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'GEE — Your AI companion', description: 'Talk, laugh, vent and connect with your AI Gee.' };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="en"><body>{children}</body></html>; }
