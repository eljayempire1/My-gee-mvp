'use client';
import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

type Connection={id:string;other_user_id:string;display_name:string;city:string|null;avatar_letter:string};
type Message={id:string;connection_id:string;sender_id:string;body:string;created_at:string};

export default function Messages(){
 const supabase=useMemo(()=>createClient(),[]);
 const [connections,setConnections]=useState<Connection[]>([]); const [selected,setSelected]=useState<Connection|null>(null);
 const [messages,setMessages]=useState<Message[]>([]); const [body,setBody]=useState(''); const [userId,setUserId]=useState('');
 const [loading,setLoading]=useState(true); const [status,setStatus]=useState('');
 useEffect(()=>{let mounted=true;(async()=>{const {data:{user}}=await supabase.auth.getUser(); if(!user){setStatus('Please sign in to message people.');setLoading(false);return;} setUserId(user.id); const {data,error}=await supabase.rpc('accepted_connections'); if(error)setStatus(error.message); else if(mounted){setConnections((data||[]) as Connection[]); if(data?.length)setSelected(data[0] as Connection);} setLoading(false);})(); return()=>{mounted=false}},[supabase]);
 useEffect(()=>{if(!selected)return; let mounted=true; (async()=>{const {data}=await supabase.from('connection_messages').select('*').eq('connection_id',selected.id).order('created_at',{ascending:true}); if(mounted)setMessages((data||[]) as Message[])})();
 const channel=supabase.channel(`connection-${selected.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'connection_messages',filter:`connection_id=eq.${selected.id}`},payload=>setMessages(m=>m.some(x=>x.id===payload.new.id)?m:[...m,payload.new as Message])).subscribe();
 return()=>{mounted=false;supabase.removeChannel(channel)};
 },[selected,supabase]);
 async function send(){const text=body.trim();if(!text||!selected||!userId)return; const {error}=await supabase.from('connection_messages').insert({connection_id:selected.id,sender_id:userId,body:text}); if(error)setStatus(error.message); else {setBody('');setStatus('Sent ✓')}}
 return <main><nav className="nav"><div className="logo">GEE<span>.</span></div><div className="navlinks"><a href="/gee">My Gee</a><a href="/matches">People</a><a className="btn ghost" href="/profile">Profile</a></div></nav><section className="chat-shell"><p className="eyebrow">LIVE CONNECTIONS</p><h1>Messages.</h1><p className="lead">Private, real-time conversations with people you chose to connect with.</p>{loading?<p>Loading your connections…</p>:connections.length===0?<div className="message-card"><p className="muted">No accepted connections yet. Find your people first.</p><a className="btn primary" href="/matches">Discover people</a></div>:<div className="live-chat"><aside className="connection-list">{connections.map(c=><button key={c.id} className={`connection-item ${selected?.id===c.id?'active':''}`} onClick={()=>setSelected(c)}><span className="avatar">{c.avatar_letter}</span><span><strong>{c.display_name}</strong><small>{c.city||'GEE member'}</small></span></button>)}</aside><div className="message-card"><div className="chat-header"><div className="avatar big">{selected?.avatar_letter}</div><div><h3>{selected?.display_name}</h3><p className="muted">{selected?.city||'GEE member'}</p></div></div><div className="messages">{messages.length===0?<p className="muted">Say hello 👋</p>:messages.map(m=><div className={`bubble ${m.sender_id===userId?'mine':''}`} key={m.id}>{m.body}</div>)}</div><div className="composer"><input value={body} onChange={e=>setBody(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Write a message…" maxLength={2000}/><button className="btn primary" onClick={send}>Send</button></div><small className="muted">{status||'Messages update live.'}</small></div></div>}</section></main>
}
