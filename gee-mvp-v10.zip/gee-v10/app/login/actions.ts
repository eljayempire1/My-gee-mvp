'use server';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
export async function login(formData:FormData){const supabase=await createClient();const {error}=await supabase.auth.signInWithPassword({email:String(formData.get('email')),password:String(formData.get('password'))});if(error) redirect('/login?error=login');redirect('/gee');}
export async function signup(formData:FormData){const supabase=await createClient();const {error}=await supabase.auth.signUp({email:String(formData.get('email')),password:String(formData.get('password'))});if(error) redirect('/login?error=signup');redirect('/gee');}
