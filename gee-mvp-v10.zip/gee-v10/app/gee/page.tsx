'use client';
import { useEffect, useState } from 'react';
import GeeChat from '@/components/GeeChat';
import GeeVoice from '@/components/GeeVoice';
export default function GeePage(){const [profile,setProfile]=useState<{name:string;personality:string}|null>(null); useEffect(()=>{const x=localStorage.getItem('gee_profile'); if(x)setProfile(JSON.parse(x));},[]); return <main><nav className="nav"><div className="logo">GEE<span>.</span></div><a className="btn ghost" href="/onboarding">Settings</a></nav><section className="gee-layout"><div><p className="eyebrow">YOUR GEE</p><h1>What’s up{profile?.name?`, ${profile.name}`:''}?</h1><p className="lead">You can talk, vent, ask questions or just chill.</p><GeeChat personality={profile?.personality||'bestie'} /></div><GeeVoice /></section></main>}
