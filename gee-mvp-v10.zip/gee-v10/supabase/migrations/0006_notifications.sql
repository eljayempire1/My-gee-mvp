create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  type text not null check (type in ('connection_request','connection_accepted','message')),
  title text not null,
  body text not null,
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
alter table public.notifications enable row level security;
create policy "Users read own notifications" on public.notifications for select using (auth.uid() = user_id);
create policy "Users update own notifications" on public.notifications for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.create_notification(p_user_id uuid,p_actor_id uuid,p_type text,p_title text,p_body text,p_data jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications(user_id,actor_id,type,title,body,data) values(p_user_id,p_actor_id,p_type,p_title,p_body,coalesce(p_data,'{}'::jsonb));
end; $$;
revoke all on function public.create_notification(uuid,uuid,text,text,text,jsonb) from public;
grant execute on function public.create_notification(uuid,uuid,text,text,text,jsonb) to authenticated;
