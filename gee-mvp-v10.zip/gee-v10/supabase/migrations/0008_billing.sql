create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  status text not null default 'inactive',
  price_id text,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;
create policy "users read own subscription" on public.subscriptions for select using (auth.uid() = user_id);

create or replace function public.is_plus(p_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.subscriptions s where s.user_id=p_user_id and s.status in ('active','trialing') and (s.current_period_end is null or s.current_period_end > now()));
$$;
revoke all on function public.is_plus(uuid) from public;
grant execute on function public.is_plus(uuid) to authenticated;
