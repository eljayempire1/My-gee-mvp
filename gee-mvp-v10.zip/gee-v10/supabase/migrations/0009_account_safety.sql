alter table public.profiles add column if not exists onboarding_complete boolean not null default false;
alter table public.profiles add column if not exists allow_messages boolean not null default true;
alter table public.profiles add column if not exists show_city boolean not null default true;
alter table public.profiles add column if not exists deleted_at timestamptz;

create table if not exists public.rate_limits (
  user_id uuid not null references auth.users(id) on delete cascade,
  bucket text not null,
  window_start timestamptz not null,
  request_count integer not null default 0,
  primary key(user_id,bucket,window_start)
);
alter table public.rate_limits enable row level security;
revoke all on public.rate_limits from public, authenticated;

create or replace function public.consume_rate_limit(p_bucket text, p_limit integer default 30, p_window_seconds integer default 60)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_start timestamptz := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds); v_count integer;
begin
  insert into public.rate_limits(user_id,bucket,window_start,request_count) values(auth.uid(),p_bucket,v_start,1)
  on conflict(user_id,bucket,window_start) do update set request_count=public.rate_limits.request_count+1
  returning request_count into v_count;
  return v_count <= greatest(1,p_limit);
end; $$;
revoke all on function public.consume_rate_limit(text,integer,integer) from public;
grant execute on function public.consume_rate_limit(text,integer,integer) to authenticated;
