-- GEE v7: realtime human-to-human messaging without colliding with My Gee AI messages.
create table if not exists public.connection_messages (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references public.connections(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists connection_messages_connection_idx on public.connection_messages(connection_id, created_at);
alter table public.connection_messages enable row level security;
create policy "connection messages readable by accepted participants" on public.connection_messages
for select using (exists (select 1 from public.connections c where c.id=connection_id and c.status='accepted' and (auth.uid()=c.requester_id or auth.uid()=c.recipient_id)));
create policy "connection messages writable by sender" on public.connection_messages
for insert with check (auth.uid()=sender_id and exists (select 1 from public.connections c where c.id=connection_id and c.status='accepted' and (auth.uid()=c.requester_id or auth.uid()=c.recipient_id)));
create policy "connection messages deletable by sender" on public.connection_messages
for delete using (auth.uid()=sender_id);

create or replace function public.accepted_connections()
returns table(id uuid, other_user_id uuid, display_name text, city text, avatar_letter text)
language sql security definer set search_path=public as $$
  select c.id,
         case when c.requester_id=auth.uid() then c.recipient_id else c.requester_id end,
         coalesce(p.display_name,'GEE member'), p.city,
         left(coalesce(p.display_name,'G'),1)
  from public.connections c
  join public.profiles p on p.id = case when c.requester_id=auth.uid() then c.recipient_id else c.requester_id end
  where c.status='accepted' and (c.requester_id=auth.uid() or c.recipient_id=auth.uid())
  order by c.created_at desc;
$$;
revoke all on function public.accepted_connections() from public;
grant execute on function public.accepted_connections() to authenticated;

-- Supabase Realtime needs the table in its publication.
alter publication supabase_realtime add table public.connection_messages;
