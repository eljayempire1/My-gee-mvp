create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (reason in ('harassment','spam','scam','sexual_content','threats','other')),
  details text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  constraint reports_not_self check (reporter_id <> reported_user_id)
);
create index if not exists reports_reported_user_idx on public.reports(reported_user_id, created_at desc);
alter table public.reports enable row level security;
create policy "Users create reports" on public.reports for insert with check (auth.uid() = reporter_id);
create policy "Users read own reports" on public.reports for select using (auth.uid() = reporter_id);
