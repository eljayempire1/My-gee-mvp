create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references public.connections(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists messages_connection_idx on public.messages(connection_id, created_at);
alter table public.messages enable row level security;
create policy "messages visible to connection participants" on public.messages for select using (
  exists (select 1 from public.connections c where c.id=connection_id and (auth.uid()=c.requester_id or auth.uid()=c.recipient_id) and c.status='accepted')
);
create policy "messages sent by participant" on public.messages for insert with check (
  auth.uid()=sender_id and exists (select 1 from public.connections c where c.id=connection_id and (auth.uid()=c.requester_id or auth.uid()=c.recipient_id) and c.status='accepted')
);
