create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

alter table public.blocks enable row level security;
create policy "users manage their own blocks" on public.blocks for all using (auth.uid() = blocker_id) with check (auth.uid() = blocker_id);

create or replace function public.connection_score(a uuid, b uuid)
returns integer
language sql
stable
as $$
  select coalesce((
    select count(*)::int
    from unnest(coalesce(p1.interests, '{}')) i
    join unnest(coalesce(p2.interests, '{}')) j on lower(i)=lower(j)
    where p1.id=a and p2.id=b
  ), 0);
$$;

create or replace function public.discover_people(limit_count integer default 20)
returns table (id uuid, display_name text, city text, bio text, interests text[], score integer)
language sql
stable
security invoker
as $$
  select p.id, p.display_name, p.city, p.bio, p.interests,
         public.connection_score(auth.uid(), p.id) as score
  from public.profiles p
  where p.id <> auth.uid()
    and not exists (select 1 from public.blocks b where b.blocker_id=auth.uid() and b.blocked_id=p.id)
    and not exists (select 1 from public.blocks b where b.blocker_id=p.id and b.blocked_id=auth.uid())
  order by score desc, p.created_at desc
  limit greatest(1, least(limit_count, 50));
$$;
