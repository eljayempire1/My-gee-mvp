create table if not exists public.connections (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','blocked')),
  created_at timestamptz not null default now(),
  unique(requester_id, recipient_id),
  check (requester_id <> recipient_id)
);
create index if not exists connections_requester_idx on public.connections(requester_id);
create index if not exists connections_recipient_idx on public.connections(recipient_id);
alter table public.connections enable row level security;
create policy "connections visible to participants" on public.connections for select using (auth.uid()=requester_id or auth.uid()=recipient_id);
create policy "connections create as requester" on public.connections for insert with check (auth.uid()=requester_id);
create policy "connections update by participants" on public.connections for update using (auth.uid()=requester_id or auth.uid()=recipient_id) with check (auth.uid()=requester_id or auth.uid()=recipient_id);

alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists city text;
alter table public.profiles add column if not exists interests text[] default '{}';
alter table public.profiles add column if not exists looking_for text[] default '{}';
alter table public.profiles add column if not exists is_discoverable boolean not null default true;
